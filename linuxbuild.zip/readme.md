### Required extra packages:
- pygame
- numpy

### Art by:
- Wulax: https://opengameart.org/content/lpc-medieval-fantasy-character-sprites
- LPC: https://lpc.opengameart.org/
- Hand icons derived from image by Evan-Amos: https://commons.wikimedia.org/wiki/File:Human-Hands-Front-Back.jpg
- SPQR icon by Ssolbergj, with modifications: https://commons.wikimedia.org/wiki/File:Roman_SPQR_banner.svg
- Daniel Eddeland: https://opengameart.org/content/lpc-farming-tilesets-magic-animations-and-ui-elements
- TheraHedwig: https://opengameart.org/content/lpc-compatible-ancient-greek-architecture
- TheraHedwig: https://opengameart.org/content/lpc-compatible-ancient-roman-architecture

### Music by:
- Synaulia: https://www.soundcenter.it/synauliaeng.htm

### Fonts by:
- Amble by Punchcut: https://www.fontsquirrel.com/fonts/amble