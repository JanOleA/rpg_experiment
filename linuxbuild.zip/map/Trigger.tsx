<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="Trigger" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="trigger.png" width="64" height="64"/>
 <tile id="0" type="Trigger">
  <properties>
   <property name="triggerid" value=""/>
  </properties>
 </tile>
 <tile id="1" type="Trigger">
  <properties>
   <property name="triggerid" value=""/>
  </properties>
 </tile>
 <tile id="2" type="Trigger"/>
 <tile id="3" type="Trigger"/>
</tileset>
