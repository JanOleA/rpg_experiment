<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="Ancient Greek" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="LPC_Ancient_Greece_Architecture.png" width="640" height="640"/>
</tileset>
