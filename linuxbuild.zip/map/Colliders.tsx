<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="Colliders" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="colliders.png" width="128" height="128"/>
 <tile id="0" type="Top"/>
 <tile id="1" type="Left"/>
 <tile id="2" type="TLRM"/>
 <tile id="3" type="LMRB"/>
 <tile id="4" type="Bottom"/>
 <tile id="5" type="Right"/>
 <tile id="6" type="LBRM"/>
 <tile id="7" type="LMRT"/>
 <tile id="10" type="LTRB"/>
 <tile id="11" type="LB"/>
 <tile id="14" type="RB"/>
 <tile id="15" type="LBRT"/>
</tileset>
